
### Overview of the app SaveMyTrip

SaveMyTrip is the mini-app that we will develop throughout this course:

![Overview of the app SaveMyTrip](https://user.oc-static.com/upload/2019/05/26/15588683548093_Capture%20d%E2%80%99e%CC%81cran%202019-05-26%20a%CC%80%2012.58.57.png)

Overview of the app SaveMyTrip

Its objective is to be able to easily organize your future trips, thanks to its fantastic travel diary as well as its interactive list of things to do, all accessible 100% off-line! 😀

