package com.example.travellingScheduler.injection

import android.arch.lifecycle.ViewModel
import android.arch.lifecycle.ViewModelProvider

import com.example.travellingScheduler.repositories.ItemDataRepository
import com.example.travellingScheduler.repositories.UserDataRepository
import com.example.travellingScheduler.todolist.ItemViewModel

import java.util.concurrent.Executor




class ViewModelFactory(private val itemDataSource: ItemDataRepository,
                       private val userDataSource: UserDataRepository,
                       private val executor: Executor) : ViewModelProvider.Factory {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return if (modelClass.isAssignableFrom(ItemViewModel::class.java)) {
            ItemViewModel(itemDataSource, userDataSource, executor) as T
        } else {
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}