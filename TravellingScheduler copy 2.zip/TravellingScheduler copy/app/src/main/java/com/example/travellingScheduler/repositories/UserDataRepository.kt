package com.example.travellingScheduler.repositories

import android.arch.lifecycle.LiveData

import com.example.travellingScheduler.database.UserDao
import com.example.travellingScheduler.models.User
class UserDataRepository(private val userDao: UserDao) {
    fun getUser(userId: Long): LiveData<User> {
        return this.userDao.getUser(userId)
    }
}
