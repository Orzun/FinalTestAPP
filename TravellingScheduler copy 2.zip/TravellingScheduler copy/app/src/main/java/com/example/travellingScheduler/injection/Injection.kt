package com.example.travellingScheduler.injection

import android.content.Context

import com.example.travellingScheduler.database.SaveMyTripDatabase
import com.example.travellingScheduler.repositories.ItemDataRepository
import com.example.travellingScheduler.repositories.UserDataRepository

import java.util.concurrent.Executor
import java.util.concurrent.Executors



object Injection {
    private fun provideItemDataSource(context: Context): ItemDataRepository {
        val database = SaveMyTripDatabase.getInstance(context)
        return ItemDataRepository(database!!.itemDao())
    }

    private fun provideUserDataSource(context: Context): UserDataRepository {
        val database = SaveMyTripDatabase.getInstance(context)
        return UserDataRepository(database!!.userDao())
    }

    private fun provideExecutor(): Executor {
        return Executors.newSingleThreadExecutor()
    }

    fun provideViewModelFactory(context: Context): ViewModelFactory {
        val dataSourceItem = provideItemDataSource(context)
        val dataSourceUser = provideUserDataSource(context)
        val executor = provideExecutor()
        return ViewModelFactory(dataSourceItem, dataSourceUser, executor)
    }
}
