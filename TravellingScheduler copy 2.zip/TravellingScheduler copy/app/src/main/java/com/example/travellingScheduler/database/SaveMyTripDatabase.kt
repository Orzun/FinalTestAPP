package com.example.travellingScheduler.database

import android.arch.persistence.db.SupportSQLiteDatabase
import android.arch.persistence.room.Database
import android.arch.persistence.room.OnConflictStrategy
import android.arch.persistence.room.Room
import android.arch.persistence.room.RoomDatabase
import android.content.ContentValues
import android.content.Context

import com.example.travellingScheduler.models.Item
import com.example.travellingScheduler.models.User




@Database(entities = [Item::class, User::class], version = 1, exportSchema = false)
abstract class SaveMyTripDatabase : RoomDatabase() {

    // --- DAO ---
    abstract fun itemDao(): ItemDao

    abstract fun userDao(): UserDao

    companion object {

        // --- SINGLETON ---
        @Volatile
        private var INSTANCE: SaveMyTripDatabase? = null

        // --- INSTANCE ---
        fun getInstance(context: Context): SaveMyTripDatabase? {
            if (INSTANCE == null) {
                synchronized(SaveMyTripDatabase::class.java) {
                    if (INSTANCE == null) {
                        INSTANCE = Room.databaseBuilder(context.applicationContext,
                                SaveMyTripDatabase::class.java, "MyDatabase.db")
                                .addCallback(prepopulateDatabase())
                                .build()
                    }
                }
            }
            return INSTANCE
        }

        // ---

        private fun prepopulateDatabase(): Callback {
            return object : Callback() {

                override fun onCreate(db: SupportSQLiteDatabase) {
                    super.onCreate(db)

                    val contentValues = ContentValues()
                    contentValues.put("id", 1)
                    contentValues.put("username", "Arjun")
                    contentValues.put("urlPicture", "https://scontent.fhnd1-1.fna.fbcdn.net/v/t1.6435-9/120497759_2740535139551812_7208164017366755251_n.jpg?_nc_cat=107&ccb=1-3&_nc_sid=8bfeb9&_nc_ohc=D3ao5noMyeIAX9_8gGW&_nc_ht=scontent.fhnd1-1.fna&oh=a94857079b16d566db6d3d2f084ba1e7&oe=60FEF23B")
                    db.insert("User", OnConflictStrategy.IGNORE, contentValues)
                }
            }
        }
    }
}


