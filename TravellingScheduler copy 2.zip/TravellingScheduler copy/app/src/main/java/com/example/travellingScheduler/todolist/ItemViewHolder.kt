package com.example.travellingScheduler.todolist

import android.graphics.Paint
import android.support.v7.widget.RecyclerView
import android.view.View
import android.widget.Button
import android.widget.TextView

import com.example.travellingScheduler.R
import com.example.travellingScheduler.models.Item

import java.lang.ref.WeakReference



class ItemViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView), View.OnClickListener {

    var textView: TextView = itemView.findViewById<View>(R.id.activity_todo_list_item_text) as TextView
    var deleteButton: Button = itemView.findViewById<View>(R.id.activity_todo_list_item_remove) as Button
    var updateButton: Button = itemView.findViewById<View>(R.id.activity_todo_list_item_update) as Button


    private var callbackWeakRef: WeakReference<ItemAdapter.Listener>? = null

    fun updateWithItem(item: Item, callback: ItemAdapter.Listener) {
        callbackWeakRef = WeakReference(callback)
        textView.text = item.text
        deleteButton.setOnClickListener(this)
//        updateButton.setOnClickListener(this)
        if (item.selected) {
            textView.paintFlags = textView.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG

        } else {
            textView.paintFlags = textView.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
        }
    }

    override fun onClick(view: View) {
        val callback = callbackWeakRef!!.get()
        callback?.onClickDeleteButton(adapterPosition)
    }
}