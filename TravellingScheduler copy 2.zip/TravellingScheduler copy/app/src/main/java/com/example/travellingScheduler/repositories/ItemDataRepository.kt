package com.example.travellingScheduler.repositories

import android.arch.lifecycle.LiveData
import com.example.travellingScheduler.database.ItemDao
import com.example.travellingScheduler.models.Item


class ItemDataRepository(private val itemDao: ItemDao) {
    fun getItems(userId: Long): LiveData<List<Item>> {
        return this.itemDao.getItems(userId)
    }

    fun createItem(item: Item) {
        itemDao.insertItem(item)
    }
    fun deleteItem(itemId: Long) {
        itemDao.deleteItem(itemId)
    }
    fun updateItem(item: Item) {
        itemDao.updateItem(item)
    }
}
