package com.example.travellingScheduler.todolist

import android.arch.lifecycle.LiveData
import android.arch.lifecycle.ViewModel

import com.example.travellingScheduler.models.Item
import com.example.travellingScheduler.models.User
import com.example.travellingScheduler.repositories.ItemDataRepository
import com.example.travellingScheduler.repositories.UserDataRepository
import java.util.concurrent.Executor



class ItemViewModel(private val itemDataSource: ItemDataRepository,
                    private val userDataRepository: UserDataRepository,
                    private val executor: Executor) : ViewModel() {
    private var currentUser: LiveData<User>? = null

    fun init(userId: Long) {
        if (currentUser != null) {
            return
        }
        currentUser = userDataRepository.getUser(userId)
    }

    fun getUser(userId: Long): LiveData<User>? {
        return currentUser
    }
    fun getItems(userId: Long): LiveData<List<Item>> {
        return itemDataSource.getItems(userId)
    }

    fun createItem(item: Item) {
        executor.execute { itemDataSource.createItem(item) }
    }

    fun deleteItem(itemId: Long) {
        executor.execute { itemDataSource.deleteItem(itemId) }
    }

    fun updateItem(item: Item) {
        executor.execute { itemDataSource.updateItem(item) }
    }
}
